<?php
$MainArr=array(1,2,3,4,5,6);
$MainArrCount=count($MainArr);
$MainArrKeyCount=count($MainArr)-1;
$NewArray=array();
foreach ($MainArr as $key => $value) {
	if($key==$MainArrKeyCount){break;}
	if($key==0){
		$NewArray[]= $value;
		$NewArray[]= $MainArr[$MainArrKeyCount];
	}else{
		$NewArray[]= $value;
	}
	
}
print_r($MainArr);
echo '<br/>';
print_r($NewArray);
?>